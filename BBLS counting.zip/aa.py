import random

arrBest = []
arrWorst =[]
arrAvg = []
for10=[]
for100=[]
for1000=[]
for10000=[]
totalCostBest = 0
totalCostWorst = 0
totalCostAvg = 0

for n in [10,100,1000]:

  for i in range(1,n,1):
    arrBest.append(i)
  #print(arrBest)

  for i in range(n,1,-1):
    arrWorst.append(i)
  #print(arrWorst)

  for i in range(n,1,-1):
    arrAvg.append(random.random())
  #print(arrAvg)


  for i in range(0,len(arrBest)-1):
    totalCostBest += 1
    for j in range(0,len(arrBest)-1):
      totalCostBest += 1
      if arrBest[j] > arrBest[j+1]:
        tmp = arrBest[j]
        arrBest[j] = arrBest[j+1]
        arrBest[j+1] = tmp
        totalCostBest += 4
  for i in range(0,len(arrWorst)-1):
    totalCostWorst += 1
    for j in range(0,len(arrWorst)-1):
      totalCostWorst += 1
      if arrWorst[j] > arrWorst[j+1]:
        tmp = arrWorst[j]
        arrWorst[j] = arrWorst[j+1]
        arrWorst[j+1] = tmp
        totalCostWorst += 4
  for i in range(0,len(arrAvg)-1):
    totalCostAvg += 1
    for j in range(0,len(arrAvg)-1):
      totalCostAvg += 1
      if arrAvg[j] > arrAvg[j+1]:
        tmp = arrAvg[j]
        arrAvg[j] = arrAvg[j+1]
        arrAvg[j+1] = tmp
        totalCostAvg += 4
        
  if n==10:
    for10.append(totalCostBest)
    for10.append(totalCostWorst)
    for10.append(totalCostAvg)
  if n==100:
    for100.append(totalCostBest)
    for100.append(totalCostWorst)
    for100.append(totalCostAvg)
  if n==1000:
    for1000.append(totalCostBest)
    for1000.append(totalCostWorst)
    for1000.append(totalCostAvg)
  '''if n==10000:
    for10000.append(totalCostBest)
    for10000.append(totalCostWorst)
    for10000.append(totalCostAvg)'''
    
print("for input 10 best:{} worst: {} avg: {}".format(for10[0],for10[1],for10[2]))
print("for input 100 best:{} worst: {} avg: {}".format(for100[0],for100[1],for100[2]))
print("for input 1000 best:{} worst: {} avg: {}".format(for1000[0],for1000[0],for1000[2]))
#print("for input 10000 best:{} worst: {} avg: {}".format(for10000[0],for10000[1],for10000[2]))